<?php
$dbuser = "root";
$dbpass = "toor";
$host = "localhost";
$db = "hmisphp";
$mysqli = new mysqli($host, $dbuser, $dbpass, $db);
