<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                2022 - <?php echo date('Y'); ?> &copy; Système d'information de gestion hospitalière. </a>
            </div>

        </div>
    </div>
</footer>