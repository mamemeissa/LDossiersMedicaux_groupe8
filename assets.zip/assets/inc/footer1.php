<footer class="footer footer-alt">
    2022 - <?php echo date('Y'); ?> &copy; Système d'information de gestion hospitalière.</a>
</footer>